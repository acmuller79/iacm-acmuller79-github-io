// IA-ACMULLER Vision API
// Análise de vídeo e imagens usando IA

export default async function handler(request, response) {
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (request.method === 'OPTIONS') {
    return response.status(200).end();
  }

  if (request.method !== 'POST') {
    return response.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { type, data, prompt = 'Descreva o conteúdo visual em detalhes' } = request.body;

    if (!data) {
      return response.status(400).json({ error: 'Data is required' });
    }

    let analysis;

    if (type === 'image') {
      analysis = await analyzeImage(data, prompt);
    } else if (type === 'video') {
      analysis = await analyzeVideo(data, prompt);
    } else {
      return response.status(400).json({ error: 'Type must be image or video' });
    }

    return response.status(200).json({
      success: true,
      type,
      analysis,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    return response.status(500).json({
      error: 'Analysis failed',
      details: error.message
    });
  }
}

// Análise de imagem usando Gemini Vision
async function analyzeImage(base64Data, prompt) {
  const { GoogleGenerativeAI } = await import('@google/generative-ai');

  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
  const model = genAI.getGenerativeModel({ model: 'gemini-pro-vision' });

  // Remove prefixo data:image/... se existir
  const base64 = base64Data.replace(/^data:image\/[^;]+;base64,/, '');

  const imagePart = {
    inlineData: {
      data: base64,
      mimeType: 'image/jpeg'
    }
  };

  const result = await model.generateContent([prompt, imagePart]);
  return result.response.text();
}

// Análise de vídeo (extrai frames e analisa)
async function analyzeVideo(videoData, prompt) {
  // Nota: Análise de vídeo completa requer processamento de frames
  // Esta é uma versão simplificada que analisa o primeiro frame

  const { GoogleGenerativeAI } = await import('@google/generative-ai');

  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
  const model = genAI.getGenerativeModel({ model: 'gemini-pro-vision' });

  // Para vídeos reais, você precisaria extrair frames primeiro
  // Aqui simulamos com uma mensagem explicativa
  const videoPrompt = `Analisando vídeo. ${prompt}. 
  Nota: Para análise completa de vídeo, extraia frames-chave (a cada 1-2 segundos) 
  e analise sequencialmente para entender o contexto temporal.`;

  // Se for base64 de um frame:
  if (videoData.startsWith('data:image')) {
    const base64 = videoData.replace(/^data:image\/[^;]+;base64,/, '');
    const imagePart = {
      inlineData: {
        data: base64,
        mimeType: 'image/jpeg'
      }
    };
    const result = await model.generateContent([videoPrompt, imagePart]);
    return result.response.text();
  }

  return videoPrompt;
}