import { google } from '@ai-sdk/google';
import { generateText } from 'ai';

export const config = {
  runtime: 'edge',
  api: {
    bodyParser: {
      sizeLimit: '10mb'
    }
  }
};

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { frames, question = 'Descreva o que está acontecendo neste vídeo', provider = 'google' } = await req.json();

    // frames é um array de base64 images (capturas do vídeo)
    if (!frames || !Array.isArray(frames) || frames.length === 0) {
      return new Response(JSON.stringify({ 
        error: 'No frames provided',
        analysis: null 
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Para análise de vídeo, usamos Gemini Pro Vision ou GPT-4 Vision
    const model = provider === 'google' 
      ? google('gemini-1.5-pro')
      : openai('gpt-4o');

    // Construir mensagem com frames
    const content = [
      { type: 'text', text: question }
    ];

    // Adicionar até 5 frames para análise
    frames.slice(0, 5).forEach(frame => {
      content.push({
        type: 'image',
        image: frame
      });
    });

    const result = await generateText({
      model,
      messages: [{ role: 'user', content }],
      system: 'Você está analisando frames de um vídeo. Descreva o conteúdo visual, ações, objetos e contexto de forma detalhada.',
      temperature: 0.5,
      maxTokens: 2048
    });

    return new Response(JSON.stringify({ 
      analysis: result.text,
      frames_analyzed: Math.min(frames.length, 5),
      provider
    }), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
