import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { google } from '@ai-sdk/google';
import { generateText, streamText } from 'ai';

export const config = {
  runtime: 'edge'
};

const providers = {
  openai: (model) => openai(model || 'gpt-4o-mini'),
  anthropic: (model) => anthropic(model || 'claude-3-haiku-20240307'),
  google: (model) => google(model || 'gemini-1.5-flash'),
  local: (model) => openai(model || 'gpt-3.5-turbo', { 
    baseURL: process.env.LOCAL_AI_URL || 'http://localhost:11434/v1',
    apiKey: 'ollama'
  })
};

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { messages, provider = 'google', model, stream = false, system } = await req.json();

    const selectedProvider = providers[provider];
    if (!selectedProvider) {
      return new Response(JSON.stringify({ error: 'Provider not supported' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const modelInstance = selectedProvider(model);

    if (stream) {
      const result = await streamText({
        model: modelInstance,
        messages,
        system: system || 'Você é o IA-ACMULLER, um assistente inteligente e prestativo.',
        temperature: 0.7,
        maxTokens: 2048
      });

      return new Response(result.toDataStream(), {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive'
        }
      });
    }

    const result = await generateText({
      model: modelInstance,
      messages,
      system: system || 'Você é o IA-ACMULLER, um assistente inteligente e prestativo.',
      temperature: 0.7,
      maxTokens: 2048
    });

    return new Response(JSON.stringify({ 
      text: result.text,
      provider,
      model: model || 'default'
    }), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
)
async function callOpenAI(message, history, mode) {
  const OpenAI = (await import('openai')).default;

  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY || ''
  });

  const messages = [
    { role: 'system', content: getSystemContext(mode) },
    ...history.map(h => ({ role: h.role, content: h.content })),
    { role: 'user', content: message }
  ];

  const completion = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages,
    temperature: 0.7
  });

  return completion.choices[0].message.content;
}

// Anthropic Claude (Free tier disponível)
async function callClaude(message, history, mode) {
  const Anthropic = (await import('@anthropic-ai/sdk')).default;

  const anthropic = new Anthropic({
    apiKey: process.env.CLAUDE_API_KEY || ''
  });

  const conversation = history.map(h => 
    `${h.role === 'user' ? 'Human' : 'Assistant'}: ${h.content}`
  ).join('\n');

  const prompt = `${getSystemContext(mode)}\n\n${conversation}\nHuman: ${message}\nAssistant:`;

  const completion = await anthropic.completions.create({
    model: 'claude-instant-1',
    max_tokens_to_sample: 1000,
    prompt
  });

  return completion.completion;
}

// Ollama (Local/Gratuito - requer servidor Ollama rodando)
async function callOllama(message, history, mode) {
  // Ollama roda localmente na porta 11434
  const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';

  const response = await fetch(`${OLLAMA_URL}/api/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'llama2',
      prompt: `${getSystemContext(mode)}\n\n${message}`,
      stream: false
    })
  });

  const data = await response.json();
  return data.response;
}

// Contexto do sistema baseado no modo
function getSystemContext(mode) {
  const contexts = {
    chat: 'Você é IA-ACMULLER, um assistente de IA amigável e prestativo. Responda em português do Brasil de forma natural e conversacional.',
    code: 'Você é IA-ACMULLER Code, um especialista em programação. Forneça código limpo, bem comentado e explicações técnicas detalhadas. Suporte múltiplas linguagens.',
    voice: 'Você é IA-ACMULLER Voice, otimizado para comandos de voz. Responda de forma concisa e clara, ideal para leitura em voz alta.',
    video: 'Você é IA-ACMULLER Vision, especialista em análise de vídeo e imagens. Descreva conteúdo visual com detalhes e contexto.',
    agent: 'Você é IA-ACMULLER Agent, um agente autônomo. Quebre tarefas complexas em passos, execute ações sequenciais e mostre seu raciocínio.'
  };
  return contexts[mode] || contexts.chat;
}