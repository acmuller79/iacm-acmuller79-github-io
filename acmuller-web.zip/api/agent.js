import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { google } from '@ai-sdk/google';
import { generateText } from 'ai';

export const config = {
  runtime: 'edge'
};

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { task, steps = [], provider = 'anthropic', context = {} } = await req.json();

    const providers = {
      openai: openai('gpt-4o'),
      anthropic: anthropic('claude-3-sonnet-20240229'),
      google: google('gemini-1.5-pro')
    };

    const model = providers[provider] || providers.anthropic;

    // Construir prompt do agente
    const systemPrompt = `Você é um Agente Autônomo do IA-ACMULLER. 
Sua tarefa atual: ${task}

Passos já executados: ${steps.length > 0 ? steps.join(', ') : 'Nenhum'}

Contexto disponível: ${JSON.stringify(context)}

Você deve:
1. Analisar o estado atual
2. Decidir o próximo passo lógico
3. Executar a ação necessária
4. Reportar o resultado

Responda em formato JSON com:
- next_step: descrição do próximo passo
- action: tipo de ação (search, code, analyze, complete)
- payload: dados necessários para a ação
- status: in_progress ou complete`;

    const result = await generateText({
      model,
      messages: [{ role: 'user', content: systemPrompt }],
      temperature: 0.4,
      maxTokens: 2048
    });

    // Tentar extrair JSON
    let agentResponse;
    try {
      const jsonMatch = result.text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        agentResponse = JSON.parse(jsonMatch[0]);
      } else {
        agentResponse = {
          next_step: 'Processar resposta',
          action: 'analyze',
          payload: { text: result.text },
          status: 'in_progress'
        };
      }
    } catch {
      agentResponse = {
        next_step: result.text,
        action: 'analyze',
        payload: {},
        status: 'in_progress'
      };
    }

    return new Response(JSON.stringify({ 
      ...agentResponse,
      provider,
      task,
      steps_completed: steps.length
    }), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
