// API Route: /api/openai.js
// Integração com OpenAI API

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { message, history = [], apiKey, model = 'gpt-3.5-turbo' } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  const key = apiKey || process.env.OPENAI_API_KEY;

  if (!key) {
    return res.status(401).json({ 
      error: 'API key not configured',
      setup: 'Obtenha sua chave em https://platform.openai.com/api-keys'
    });
  }

  try {
    const messages = [
      { role: 'system', content: 'Você é o IA-ACMULLER, um assistente de IA brasileiro útil e amigável. Responda em português do Brasil.' },
      ...history,
      { role: 'user', content: message }
    ];

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model,
        messages: messages,
        temperature: 0.7,
        max_tokens: 2048,
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    const text = data.choices?.[0]?.message?.content || 'Sem resposta';

    return res.status(200).json({ 
      response: text,
      model: model,
      provider: 'openai'
    });

  } catch (error) {
    console.error('OpenAI API Error:', error);
    return res.status(500).json({ 
      error: error.message,
      provider: 'openai'
    });
  }
}