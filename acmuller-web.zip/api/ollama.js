// API Route: /api/ollama.js
// Integração com Ollama (rodando localmente)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { message, history = [], ollamaUrl = 'http://localhost:11434', model = 'llama2' } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  try {
    // Nota: Ollama local não pode ser acessado diretamente do Vercel
    // Retornar instruções de setup

    return res.status(200).json({
      response: `## 🏠 Ollama Local

Para usar Ollama localmente:

1. **Instale o Ollama**: https://ollama.com
2. **Baixe um modelo**:
   \`\`\`bash
   ollama pull llama3
   ollama pull mistral
   \`\`\`
3. **Inicie o servidor**:
   \`\`\`bash
   ollama serve
   \`\`\`
4. **Use tunnel local** (para acesso externo):
   \`\`\`bash
   npx localtunnel --port 11434
   # ou
   ngrok http 11434
   \`\`\`

**Sua mensagem:** ${message.substring(0, 50)}...`,
      model: model,
      provider: 'ollama',
      local: true,
      setup_required: true
    });

  } catch (error) {
    return res.status(500).json({ 
      error: error.message,
      provider: 'ollama'
    });
  }
}