import { openai } from '@ai-sdk/openai';
import { google } from '@ai-sdk/google';
import { generateText } from 'ai';

export const config = {
  runtime: 'edge'
};

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { transcript, provider = 'google' } = await req.json();

    const providers = {
      openai: openai('gpt-4o-mini'),
      google: google('gemini-1.5-flash')
    };

    const model = providers[provider] || providers.google;

    const result = await generateText({
      model,
      messages: [{ role: 'user', content: transcript }],
      system: 'Você está respondendo a um comando de voz. Seja conciso e direto. Se o usuário pedir para gerar código, gere código. Se pedir informações, forneça-as de forma clara.',
      temperature: 0.7,
      maxTokens: 1024
    });

    return new Response(JSON.stringify({ 
      text: result.text,
      provider,
      type: 'voice_response'
    }), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
