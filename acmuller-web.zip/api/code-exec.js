// IA-ACMULLER Code Execution API
// Executa código em sandbox seguro (JavaScript/Python simulado)

export default async function handler(request, response) {
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (request.method === 'OPTIONS') {
    return response.status(200).end();
  }

  if (request.method !== 'POST') {
    return response.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { code, language = 'javascript' } = request.body;

    if (!code) {
      return response.status(400).json({ error: 'Code is required' });
    }

    let result;

    switch(language.toLowerCase()) {
      case 'javascript':
      case 'js':
        result = await executeJavaScript(code);
        break;
      case 'python':
      case 'py':
        result = await simulatePython(code);
        break;
      default:
        result = { output: '', error: 'Linguagem não suportada. Use javascript ou python.' };
    }

    return response.status(200).json({
      success: true,
      language,
      ...result,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    return response.status(500).json({
      error: 'Execution failed',
      details: error.message
    });
  }
}

// Executa JavaScript em VM isolada (simulado - em produção usar vm2 ou similar)
async function executeJavaScript(code) {
  // Simulação segura - em produção usar bibliotecas de sandbox
  const logs = [];
  const mockConsole = {
    log: (...args) => logs.push(args.join(' ')),
    error: (...args) => logs.push('Error: ' + args.join(' ')),
    warn: (...args) => logs.push('Warn: ' + args.join(' '))
  };

  try {
    // Cria função isolada com console mockado
    const func = new Function('console', code);
    const result = func(mockConsole);

    return {
      output: logs.join('\n') || String(result),
      logs: logs,
      error: null
    };
  } catch (err) {
    return {
      output: '',
      logs: logs,
      error: err.message
    };
  }
}

// Simula Python (análise sintática básica)
async function simulatePython(code) {
  // Versão simulada - integração real requer Python runtime
  const lines = code.split('\n');
  const output = [];
  const variables = {};

  for (let line of lines) {
    line = line.trim();
    if (line.startsWith('print(')) {
      const content = line.slice(6, -1);
      if (content.startsWith('"') || content.startsWith("'")) {
        output.push(content.slice(1, -1));
      } else if (variables[content]) {
        output.push(variables[content]);
      } else {
        output.push(content);
      }
    } else if (line.includes('=') && !line.startsWith('#')) {
      const [varName, value] = line.split('=').map(s => s.trim());
      if (value.startsWith('"') || value.startsWith("'")) {
        variables[varName] = value.slice(1, -1);
      } else if (!isNaN(value)) {
        variables[varName] = Number(value);
      } else {
        variables[varName] = value;
      }
    }
  }

  return {
    output: output.join('\n'),
    logs: output,
    error: null,
    note: 'Execução Python simulada. Para execução real, configure um runtime Python.'
  };
}