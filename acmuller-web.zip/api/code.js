import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { google } from '@ai-sdk/google';
import { generateText } from 'ai';
import { z } from 'zod';

export const config = {
  runtime: 'edge'
};

const codeSchema = z.object({
  code: z.string(),
  language: z.string(),
  explanation: z.string(),
  dependencies: z.array(z.string()).optional()
});

const providers = {
  openai: (model) => openai(model || 'gpt-4o'),
  anthropic: (model) => anthropic(model || 'claude-3-sonnet-20240229'),
  google: (model) => google(model || 'gemini-1.5-pro')
};

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const { prompt, language = 'javascript', provider = 'openai' } = await req.json();

    const selectedProvider = providers[provider];
    if (!selectedProvider) {
      return new Response(JSON.stringify({ error: 'Provider not supported' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const systemPrompt = `Você é um expert em programação. Gere código em ${language} com:
1. Código limpo e bem documentado
2. Explicação detalhada do funcionamento
3. Lista de dependências necessárias (se houver)
4. Exemplos de uso

Retorne em formato JSON com: code, language, explanation, dependencies`;

    const result = await generateText({
      model: selectedProvider(),
      prompt: `${systemPrompt}

Solicitação: ${prompt}`,
      temperature: 0.3,
      maxTokens: 3000
    });

    // Tentar extrair JSON da resposta
    let parsed;
    try {
      const jsonMatch = result.text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsed = JSON.parse(jsonMatch[0]);
      } else {
        parsed = {
          code: result.text,
          language,
          explanation: 'Código gerado pelo IA-ACMULLER',
          dependencies: []
        };
      }
    } catch {
      parsed = {
        code: result.text,
        language,
        explanation: 'Código gerado pelo IA-ACMULLER',
        dependencies: []
      };
    }

    return new Response(JSON.stringify(parsed), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
