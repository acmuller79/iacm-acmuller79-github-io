// API Route: /api/claude.js
// Integração com Anthropic Claude API

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { message, history = [], apiKey, model = 'claude-3-haiku-20240307' } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  const key = apiKey || process.env.CLAUDE_API_KEY;

  if (!key) {
    return res.status(401).json({ 
      error: 'API key not configured',
      setup: 'Obtenha sua chave em https://console.anthropic.com/'
    });
  }

  try {
    // Formatar histórico para formato Claude
    const formattedHistory = history.map(h => ({
      role: h.role === 'assistant' ? 'assistant' : 'user',
      content: h.content
    }));

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model,
        max_tokens: 2048,
        messages: [
          ...formattedHistory,
          { role: 'user', content: message }
        ],
        system: 'Você é o IA-ACMULLER, um assistente de IA brasileiro útil e amigável. Responda em português do Brasil.'
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    const text = data.content?.[0]?.text || 'Sem resposta';

    return res.status(200).json({ 
      response: text,
      model: model,
      provider: 'anthropic'
    });

  } catch (error) {
    console.error('Claude API Error:', error);
    return res.status(500).json({ 
      error: error.message,
      provider: 'claude'
    });
  }
}