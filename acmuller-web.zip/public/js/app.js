// IA-ACMULLER Web App - JavaScript Principal
// Gerencia chat, código, voz, vídeo e agente autônomo

const CONFIG = {
    API_BASE_URL: '/api',
    DEFAULT_MODEL: 'gemini',
    DEFAULT_MODE: 'chat',
    MAX_HISTORY: 50
};

// Estado global
const state = {
    currentMode: 'chat',
    currentModel: 'gemini',
    messages: [],
    isTyping: false,
    isRecording: false,
    settings: {
        autoSpeak: true,
        streamResponse: true,
        apiKeys: {}
    }
};

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});

// App Principal
const app = {
    init() {
        this.loadSettings();
        this.setMode('chat');
        this.showWelcomeMessage();
        console.log('🤖 IA-ACMULLER v2.0 Web iniciado');
    },

    setMode(mode) {
        state.currentMode = mode;

        // Atualizar UI
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });

        // Esconder todos os containers
        ['chat', 'code', 'voice', 'video', 'agent'].forEach(m => {
            const container = document.getElementById(`${m}Container`);
            if (container) container.classList.add('hidden');
        });

        // Mostrar container atual
        const currentContainer = document.getElementById(`${mode}Container`);
        if (currentContainer) currentContainer.classList.remove('hidden');

        // Atualizar título
        const titles = {
            chat: 'Chat',
            code: 'Editor de Código',
            voice: 'Comandos de Voz',
            video: 'Análise de Vídeo',
            agent: 'Agente Autônomo'
        };
        document.getElementById('modeTitle').textContent = titles[mode];

        // Ajustar placeholder do input
        const placeholders = {
            chat: 'Digite sua mensagem...',
            code: 'Descreva o código que você precisa...',
            voice: 'Clique no microfone e fale...',
            video: 'Descreva o que analisar no vídeo...',
            agent: 'Descreva a tarefa para o agente executar...'
        };
        document.getElementById('messageInput').placeholder = placeholders[mode];

        // Inicializar modo específico
        if (mode === 'voice') voiceManager.init();
        if (mode === 'code') codeManager.init();
    },

    changeModel(model) {
        state.currentModel = model;
        uiManager.showToast(`Modelo alterado para: ${model}`);
    },

    showWelcomeMessage() {
        const welcome = {
            role: 'assistant',
            content: `👋 **Bem-vindo à IA-ACMULLER v2.0 Web!**

Estou rodando 100% na web, sem necessidade de Android ou Termux.

**🌟 Funcionalidades disponíveis:**
• 💬 **Chat** - Converse comigo sobre qualquer assunto
• 💻 **Código** - Escreva e execute código JavaScript/Python
• 🎙️ **Voz** - Fale comigo usando reconhecimento de voz
• 📹 **Vídeo** - Analise imagens e vídeos
• 🤖 **Agente** - Deixe-me executar tarefas autônomas

**🧠 Modelos de IA:**
• 🌟 Gemini (Google) - Recomendado, gratuito
• 🧠 OpenAI GPT - Requer API key
• ⚡ Claude (Anthropic) - Requer API key  
• 🏠 Ollama - Para uso local

Como posso ajudar você hoje?`
        };
        chatManager.addMessage(welcome);
    },

    loadSettings() {
        const saved = localStorage.getItem('acmuller_settings');
        if (saved) {
            state.settings = { ...state.settings, ...JSON.parse(saved) };
        }
    },

    saveSettings() {
        localStorage.setItem('acmuller_settings', JSON.stringify(state.settings));
    }
};

// Gerenciador de Chat
const chatManager = {
    async sendMessage() {
        const input = document.getElementById('messageInput');
        const message = input.value.trim();

        if (!message || state.isTyping) return;

        // Adicionar mensagem do usuário
        chatManager.addMessage({ role: 'user', content: message });
        input.value = '';
        uiManager.autoResize(input);

        // Mostrar indicador de digitação
        state.isTyping = true;
        uiManager.showTypingIndicator();

        try {
            // Preparar histórico
            const history = state.messages.slice(-CONFIG.MAX_HISTORY).map(m => ({
                role: m.role,
                content: m.content.replace(/\*\*/g, '') // Remove markdown para API
            }));

            // Chamada API
            const response = await fetch(`${CONFIG.API_BASE_URL}/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message,
                    model: state.currentModel,
                    mode: state.currentMode,
                    history
                })
            });

            const data = await response.json();

            uiManager.hideTypingIndicator();

            if (data.success) {
                chatManager.addMessage({
                    role: 'assistant',
                    content: data.reply,
                    model: data.model
                });

                // Falar se estiver no modo voz
                if (state.currentMode === 'voice' && state.settings.autoSpeak) {
                    voiceManager.speak(data.reply);
                }
            } else {
                throw new Error(data.error || 'Erro na resposta');
            }

        } catch (error) {
            uiManager.hideTypingIndicator();
            chatManager.addMessage({
                role: 'assistant',
                content: `❌ **Erro:** ${error.message}\n\nVerifique se a API key está configurada em Configurações ⚙️`
            });
        } finally {
            state.isTyping = false;
        }
    },

    addMessage(message) {
        state.messages.push(message);
        uiManager.renderMessage(message);
        uiManager.scrollToBottom();
    },

    newChat() {
        state.messages = [];
        document.getElementById('messages').innerHTML = '';
        app.showWelcomeMessage();
    }
};

// Gerenciador de UI
const uiManager = {
    renderMessage(message) {
        const container = document.getElementById('messages');
        const div = document.createElement('div');
        div.className = `message ${message.role}`;

        const avatar = message.role === 'user' ? '👤' : '🤖';
        const content = this.formatMessage(message.content);

        div.innerHTML = `
            <div class="message-avatar">${avatar}</div>
            <div class="message-content">${content}</div>
        `;

        container.appendChild(div);

        // Aplicar syntax highlight
        div.querySelectorAll('pre code').forEach((block) => {
            if (window.hljs) hljs.highlightElement(block);
        });
    },

    formatMessage(content) {
        // Converter markdown básico
        return content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
                return `<pre><code class="language-${lang || 'plaintext'}">${this.escapeHtml(code)}</code></pre>`;
            })
            .replace(/\n/g, '<br>');
    },

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    showTypingIndicator() {
        const container = document.getElementById('messages');
        const div = document.createElement('div');
        div.id = 'typingIndicator';
        div.className = 'message assistant';
        div.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="message-content">
                <div class="typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
        container.appendChild(div);
        this.scrollToBottom();
    },

    hideTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) indicator.remove();
    },

    scrollToBottom() {
        const container = document.getElementById('chatContainer');
        container.scrollTop = container.scrollHeight;
    },

    autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    },

    handleKeyDown(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            chatManager.sendMessage();
        }
    },

    toggleTheme() {
        document.body.classList.toggle('light-theme');
        const isLight = document.body.classList.contains('light-theme');
        localStorage.setItem('acmuller_theme', isLight ? 'light' : 'dark');
    },

    showSettings() {
        document.getElementById('settingsModal').classList.remove('hidden');
        // Carregar valores salvos
        document.getElementById('geminiKey').value = state.settings.apiKeys.gemini || '';
        document.getElementById('openaiKey').value = state.settings.apiKeys.openai || '';
        document.getElementById('claudeKey').value = state.settings.apiKeys.claude || '';
        document.getElementById('autoSpeak').checked = state.settings.autoSpeak;
        document.getElementById('streamResponse').checked = state.settings.streamResponse;
    },

    hideSettings() {
        document.getElementById('settingsModal').classList.add('hidden');
    },

    saveSettings() {
        state.settings.apiKeys = {
            gemini: document.getElementById('geminiKey').value,
            openai: document.getElementById('openaiKey').value,
            claude: document.getElementById('claudeKey').value
        };
        state.settings.autoSpeak = document.getElementById('autoSpeak').checked;
        state.settings.streamResponse = document.getElementById('streamResponse').checked;

        app.saveSettings();
        this.hideSettings();
        this.showToast('Configurações salvas!');
    },

    attachFile() {
        const input = document.createElement('input');
        input.type = 'file';
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                chatManager.addMessage({
                    role: 'user',
                    content: `📎 Anexado: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`
                });
                // Aqui você implementaria upload real
                this.showToast('Arquivo anexado (simulação)');
            }
        };
        input.click();
    },

    showToast(message) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            bottom: 100px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--primary);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        `;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }
};

// Gerenciador de Voz
const voiceManager = {
    recognition: null,
    synthesis: window.speechSynthesis,

    init() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            this.recognition.lang = 'pt-BR';
            this.recognition.continuous = false;
            this.recognition.interimResults = true;

            this.recognition.onresult = (event) => {
                const transcript = Array.from(event.results)
                    .map(result => result[0])
                    .map(result => result.transcript)
                    .join('');

                document.getElementById('voiceTranscript').textContent = transcript;

                if (event.results[0].isFinal) {
                    document.getElementById('messageInput').value = transcript;
                    chatManager.sendMessage();
                }
            };

            this.recognition.onerror = (event) => {
                console.error('Voice error:', event.error);
                this.stopRecording();
                uiManager.showToast('Erro no reconhecimento de voz');
            };

            this.recognition.onend = () => {
                this.stopRecording();
            };
        } else {
            document.querySelector('.voice-status').textContent = 
                'Reconhecimento de voz não suportado neste navegador';
        }
    },

    toggleRecording() {
        if (state.isRecording) {
            this.stopRecording();
        } else {
            this.startRecording();
        }
    },

    startRecording() {
        if (!this.recognition) {
            uiManager.showToast('Reconhecimento de voz não disponível');
            return;
        }

        state.isRecording = true;
        document.getElementById('micBtn').classList.add('recording');
        document.querySelector('.voice-waves').classList.add('recording');
        document.querySelector('.voice-status').textContent = 'Ouvindo... fale agora';

        this.recognition.start();
    },

    stopRecording() {
        state.isRecording = false;
        document.getElementById('micBtn').classList.remove('recording');
        document.querySelector('.voice-waves').classList.remove('recording');
        document.querySelector('.voice-status').textContent = 'Clique no microfone para falar';

        if (this.recognition) {
            this.recognition.stop();
        }
    },

    speak(text) {
        if (!this.synthesis) return;

        // Cancelar fala anterior
        this.synthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'pt-BR';
        utterance.rate = 1;
        utterance.pitch = 1;

        this.synthesis.speak(utterance);
    }
};

// Gerenciador de Código
const codeManager = {
    init() {
        // Carregar exemplo inicial
        console.log('Code editor initialized');
    },

    changeLanguage(lang) {
        const templates = {
            javascript: '// JavaScript\nconsole.log("Hello World");',
            python: '# Python\nprint("Hello World")',
            html: '<!-- HTML -->\n<h1>Hello World</h1>',
            css: '/* CSS */\nbody { color: blue; }'
        };

        const editor = document.getElementById('codeEditor');
        if (editor.value === '' || confirm('Trocar linguagem limpará o código. Continuar?')) {
            editor.value = templates[lang] || '';
        }
    },

    async runCode() {
        const code = document.getElementById('codeEditor').value;
        const lang = document.getElementById('languageSelect').value;
        const outputEl = document.getElementById('outputContent');

        outputEl.textContent = 'Executando...';

        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/code-exec`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, language: lang })
            });

            const data = await response.json();

            if (data.success) {
                outputEl.textContent = data.output || '(sem saída)';
                if (data.error) {
                    outputEl.textContent += '\n\nErro: ' + data.error;
                }
            } else {
                outputEl.textContent = 'Erro: ' + (data.error || 'Falha na execução');
            }
        } catch (error) {
            outputEl.textContent = 'Erro de conexão: ' + error.message;
        }
    },

    shareCode() {
        const code = document.getElementById('codeEditor').value;
        navigator.clipboard.writeText(code).then(() => {
            uiManager.showToast('Código copiado para clipboard!');
        });
    }
};

// Gerenciador de Vídeo
const videoManager = {
    async handleFile(input) {
        const file = input.files[0];
        if (!file) return;

        const uploadArea = document.getElementById('videoUploadArea');
        const preview = document.getElementById('videoPreview');
        const videoPlayer = document.getElementById('videoPlayer');
        const imagePreview = document.getElementById('imagePreview');
        const analysis = document.getElementById('videoAnalysis');
        const analysisContent = document.getElementById('analysisContent');

        uploadArea.classList.add('hidden');
        preview.classList.remove('hidden');

        const url = URL.createObjectURL(file);

        if (file.type.startsWith('video/')) {
            videoPlayer.src = url;
            videoPlayer.classList.remove('hidden');
            imagePreview.classList.add('hidden');
        } else {
            imagePreview.src = url;
            imagePreview.classList.remove('hidden');
            videoPlayer.classList.add('hidden');
        }

        // Análise simulada
        analysis.classList.remove('hidden');
        analysisContent.innerHTML = '<div class="loading"></div> Analisando...';

        try {
            // Converter para base64
            const base64 = await this.fileToBase64(file);

            const response = await fetch(`${CONFIG.API_BASE_URL}/analyze`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: file.type.startsWith('video/') ? 'video' : 'image',
                    data: base64
                })
            });

            const data = await response.json();

            if (data.success) {
                analysisContent.textContent = data.analysis;
            } else {
                analysisContent.textContent = 'Erro na análise: ' + (data.error || 'Desconhecido');
            }
        } catch (error) {
            analysisContent.textContent = 'Erro: ' + error.message + 
                '\n\nNota: Certifique-se de ter configurado a API key do Gemini nas configurações.';
        }
    },

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }
};

// Agente Autônomo
const agentManager = {
    tasks: [],

    addTask(description) {
        const task = {
            id: Date.now(),
            description,
            status: 'pending',
            steps: []
        };
        this.tasks.push(task);
        this.renderTasks();
        this.log(`Tarefa adicionada: ${description}`);
        return task;
    },

    completeTask(id) {
        const task = this.tasks.find(t => t.id === id);
        if (task) {
            task.status = 'completed';
            this.renderTasks();
            this.log(`Tarefa concluída: ${task.description}`);
        }
    },

    renderTasks() {
        const container = document.getElementById('taskList');
        if (this.tasks.length === 0) {
            container.innerHTML = '<div class="empty-tasks">Nenhuma tarefa ativa</div>';
            return;
        }

        container.innerHTML = this.tasks.map(task => `
            <div class="task-item ${task.status}">
                <span class="task-status">${task.status === 'completed' ? '✅' : '⏳'}</span>
                <span>${task.description}</span>
            </div>
        `).join('');
    },

    log(message) {
        const logContainer = document.getElementById('agentLog');
        const time = new Date().toLocaleTimeString('pt-BR');
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        entry.innerHTML = `<span class="log-time">[${time}]</span> ${message}`;
        logContainer.appendChild(entry);
        logContainer.scrollTop = logContainer.scrollHeight;
    }
};

// Exportar para uso global (se necessário)
window.app = app;
window.chatManager = chatManager;
window.uiManager = uiManager;
window.voiceManager = voiceManager;
window.codeManager = codeManager;
window.videoManager = videoManager;
window.agentManager = agentManager;
